﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer
{
    public class Catalog


    {
        public Dictionary<int, Donut> products { get; set; } = new Dictionary<int, Donut>();
    }
}
