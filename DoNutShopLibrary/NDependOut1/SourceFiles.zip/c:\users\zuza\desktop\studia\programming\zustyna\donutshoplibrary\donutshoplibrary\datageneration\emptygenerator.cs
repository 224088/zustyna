﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.DataGeneration
{
    public class EmptyGenerator : IGenerator
    {

       
        public void GenarateData(DataContext data)
        {
            
        }
    }
}
